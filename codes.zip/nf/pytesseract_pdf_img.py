## using wand library and  library and pytesseract
from wand.image import Image
for i in range (1,11):
	pdf=Image(filename=str(i)+".pdf", resolution=300)
	pdfImage=pdf.convert("jpeg")
	j=1
	for img in pdfImage.sequence:
		page=Image(image=img)
		page.save(filename=str(i)+str(j)+".jpg")
		j=j+1;
