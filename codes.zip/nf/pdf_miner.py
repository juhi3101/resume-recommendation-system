import os
from io import StringIO
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfinterp import PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from pathlib import Path
import time


def pdf_text(spath,dpath):

    if spath == "":
        spath = os.getcwd() + "\\" #if no spath passed as source_dir then it will work in curreent dir.
    print(spath)
    all_files=os.listdir(spath) # all_files is the list of the files present in -> working dir 
    
    for files in all_files:
       
        if files.endswith('.pdf'):
            rsrcmgr = PDFResourceManager()
            retstr = StringIO()
            codec = 'utf-8'
            laparams = LAParams()
            device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
            interpreter = PDFPageInterpreter(rsrcmgr, device)
            caching = True
            pagenos = set()
            fp = open(str(spath)+str(files), 'rb')
            for page in PDFPage.get_pages(fp, pagenos,caching=caching,check_extractable=True):
                interpreter.process_page(page)

            fp.close()
            device.close()
            text = retstr.getvalue()
            retstr.close()
                
            file_name=os.path.splitext(files)[0]  # file_name is the name of file without extension
            
            txt_file = open(str(dpath) + str(file_name)+".txt", "w") #make text file
            txt_file.write(text) #write text to text file
            txt_file.close()
            print(files, end="")
            print(", status = completed")

def main():
    spath = r"/home/amit/Desktop/ts/pdf/"
    dpath = r"/home/amit/Desktop/ts/txt/"
    start_time = time.time()
    pdf_text(spath,dpath)
    print("--- %s seconds ---" % (time.time() - start_time))

if __name__ == '__main__':
    main()