import os
import re
from io import StringIO
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfinterp import PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from pathlib import Path
import string
from nltk.corpus import stopwords
from nltk.tokenize.mwe import MWETokenizer
import pandas as pd
from nltk.util import ngrams
import time
from gensim.models import Word2Vec
from gensim.models import KeyedVectors
import pickle
import numpy as np
from math import sqrt


def pdf_text(spath,dpath):
    if spath == "":
        spath = os.getcwd() + "\\" #if no spath passed as source_dir then it will work in curreent dir.
    #print(spath)
    all_files=os.listdir(spath) # all_files is the list of the files present in -> working dir 
    
    for files in all_files:
       
        if files.endswith('.pdf'):
            rsrcmgr = PDFResourceManager()
            retstr = StringIO()
            codec = 'utf-8'
            laparams = LAParams()
            device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
            interpreter = PDFPageInterpreter(rsrcmgr, device)
            caching = True
            pagenos = set()
            fp = open(str(spath)+str(files), 'rb')
            for page in PDFPage.get_pages(fp, pagenos,caching=caching,check_extractable=True):
                interpreter.process_page(page)

            fp.close()
            device.close()
            text = retstr.getvalue()
            retstr.close()
                
            file_name=os.path.splitext(files)[0]  # file_name is the name of file without extension
            
            txt_file = open(str(dpath) + str(file_name)+".txt", "w") #make text file
            txt_file.write(text) #write text to text file
            txt_file.close()
            print(files, end="")
            print(", status = completed")

def get_details(spath):
    #given skill_set
    text=open('Uni_skills.csv').read() 
    skills= text.split('\n')
    #normalize
    lst1 = [word.lower() for word in skills]
    
    with open('training_data.csv', 'r') as myfile:
        data=myfile.read()
        lst_of_list=[i.strip().split(',') for i in data.split('\n') if len(i.strip())>0]

    lst_of_list.append(lst1)
    
    print("W2V Loading...", end=" ")
    w2v_model=Word2Vec(lst_of_list, min_count=1, size=100,workers=2)
    print("Completed!")
    
    #searching for skill vector ... checking for given set(excelsheet 1007)
    pskill_vec=np.zeros(100)
    count=0
    for keyw in lst1:
        vec=w2v_model.wv[keyw]
        pskill_vec +=vec
        count +=1

    pskill_vec /=count
    #print(pskill_vec)  

    all_files=os.listdir(spath)
    for files in all_files:

        # load stopwords
        stop_words = set(stopwords.words("english"))
        
        fp=open(str(spath)+str(files))
        text=fp.read() # here text is a string which have all the content of file in string format

        get_email = re.findall(r'[\w\.-]+@[\w\.-]+', text)
        #print(get_email)

        get_phone=re.findall(r'[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]', text)
        #print(get_phone)

        #print(files, end=" ")
        text = re.sub('[^a-zA-Z0-9_#+]+', ' ', text)   
        #print(text)
        
        # tokenize
        tokenizer = MWETokenizer()
        tokenizer.add_mwe(('C','#'))
        text=tokenizer.tokenize(text.split())


        #normalize
        text = [word.lower() for word in text]
        
        #remove digits
        pattern = '[0-9]'
        text = [re.sub(pattern, '', i) for i in text] 
        
        #after removing the digits we may get some empty strings
        text = [word for word in text if word!=""]      
        #print(text)
        
        fp=open('Uni_skills.csv').read()
        skills= fp.split('\n')
        
        #normalize
        skills = [word.lower() for word in skills]
        
        #print(text)
        skill_set=[]
        #print()
        for n in range (1,11):
            #print(n)
            n_grams = ngrams(text, n)
            list=[ ' '.join(grams) for grams in n_grams]
            #print(list)
            for word in list:
                if word in skills:
                    skill_set.append(word)

        skill_set=set(skill_set)
        #print(skill_set)
        #print()

        #vector evaluation part 
        rskill_vec=np.zeros(100)
        count=0
        for keyw in skill_set:
            vec=w2v_model.wv[keyw]
            rskill_vec +=vec
            count +=1

        rskill_vec /=count
        #print(rskill_vec)

        #similarity
        cosine_similarity=(np.dot(pskill_vec, rskill_vec) / (sqrt(np.dot(pskill_vec, pskill_vec)) * sqrt(np.dot(rskill_vec, rskill_vec))))
        print(files, end=" ")
        print(cosine_similarity)
def main():
    spath = r"/home/amit/Desktop/ts/pdf/"
    dpath = r"/home/amit/Desktop/ts/txt/"
    start_time = time.time()
    pdf_text(spath,dpath)
    print("Pdf->Text conversion done... ")
    spath=dpath
    get_details(spath)
    print("--- %s seconds ---" % (time.time() - start_time))

if __name__ == '__main__':
    main()