import nltk
import re
from nltk.tokenize import sent_tokenize 
from nltk.corpus import stopwords 
from nltk.util import ngrams
from nltk.tokenize import word_tokenize
from gensim.models import Word2Vec
from gensim.models import KeyedVectors
import pickle
from gensim.test.utils import common_texts, get_tmpfile 


xp=open("stopwords.txt")
text=xp.read()
xp.close()

stop_words = set(stopwords.words('english')) 

fp=open("corpus_b.txt")
text=fp.read()
fp.close()

text = text.lower()
text = re.sub('[^a-zA-Z_#+.]+', ' ',text)
text=text.replace('u+','')
sent_token=sent_tokenize(text)
print(len(sent_token))
for i in range(0,len(sent_token)):
	sent_token[i] = sent_token[i][:-1]

corpus_list=[]
for i in range(0,len(sent_token)):
  lst=sent_token[i].split(' ')
  lst=[word for word in lst if not word in stop_words]
  lst=[word for word in lst if word!='']
  sent = ' '.join(lst)
  lst=[]

  for n in range(1,4):
    temp = ngrams(sent.split(' '), n)
    temp = [' '.join(grams) for grams in temp]
    lst+=temp
  corpus_list.append(lst)

corpus_list=[l for l in corpus_list if l!=[]]

print("Training on progress...")

model=Word2Vec(corpus_list, min_count=2, size=200,workers=2)

print("Completed--!")

words=list(model.wv.vocab)
print(len(words))
printf("Model saved--!")