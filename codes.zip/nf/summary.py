import wikipedia

fp=open('MachineLearning.txt')
text=fp.read()
text=text.split('\n')
fp.close()
text.sort()
st=""
fail=[]
for i in range(0,len(text)):
  try:
    summary=wikipedia.summary(text[i])
    st=st+summary
    print(i)
    print(summary)
  except:
    fail.append(i)
print(fail)
fp=open("new.txt","w")
fp.write(st)
fp.close()