import io
import os
from pathlib import Path
from PIL import Image
import pytesseract
from wand.image import Image as WI


spath = r"/home/amit/Desktop/ts"
all_files=os.listdir(spath) # all_files is the list of the files present in spath i.e. working dir 

for files in all_files:

	if files.endswith('.pdf'):
	
		file_name=os.path.splitext(files)[0]  # file_name is the name of file without extension
		print(file_name)

		pdf = WI(filename=files, resolution=300)
		pdfImg =  pdf.convert("jpeg")

		imgBlobs = []

		for img in pdfImg.sequence:
			page = WI(image=img)
			imgBlobs.append(page.make_blob('jpeg'))

		file = open("output/"+str(file_name)+".txt","w") #write mode 

		for imgBlob in imgBlobs:
			im = Image.open(io.BytesIO(imgBlob))
			txt = pytesseract.image_to_string(im, lang="eng")
			file.write(txt)

		file.close()

	else:
		pass 











