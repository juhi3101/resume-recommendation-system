import re
from nltk.corpus import stopwords
from nltk.util import ngrams
from gensim.models import Word2Vec
from gensim.models import KeyedVectors
from nltk.tokenize import sent_tokenize 
from nltk.tokenize import word_tokenize 
import os

stop_words = set(stopwords.words("english"))
spath = r"/home/amit/Desktop/ts/txt/"
dictn={'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,'eight':8,'nine':9,'ten':10, 'eleven':11,'twelve':12,'thirteen':13,'forteen':14,'fifteen':15}
all_files=os.listdir(spath) # all_files is the list of the files present in -> working dir 
for files in all_files:
    fp = open(str(spath)+str(files))
    text=fp.read()
    text = re.sub('[^a-zA-Z0-9.-]+', ' ',text)
    text = text.lower()
    token=sent_tokenize(text)
    word ="experience"
    exp_y=0.0
    exp_m=0.0
    for line in token:
        if word in line:
            words=line.split()

            for i in range(0,len(words)):
                exp=words[i-1]
                if(words[i]=='year' or words[i]=='years'):
                    if exp in dictn:
                        exp_y=exp_y+float(dictn[exp])
                    else:
                        try:
                            isinstance(float(exp),(float))
                            exp_y=exp_y+float(exp)
                        except ValueError:
                            pass

                elif(words[i]=='month' or words[i]=='months'):
                    if exp in dictn:
                        exp_m=exp_m+float(dictn[exp])
                    else:
                        try:
                            isinstance(float(exp),(float))
                            exp_m=exp_m+float(exp)
                        except ValueError:
                            pass
        else:
            pass

    print(str(exp_y+(exp_m/12))+str(' years'), files)
