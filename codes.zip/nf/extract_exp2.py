from nltk.corpus import stopwords
from nltk.util import ngrams
from gensim.models import Word2Vec
from gensim.models import KeyedVectors
from nltk.tokenize import sent_tokenize 
from nltk.tokenize import word_tokenize 
import nltk
from nltk.tokenize import RegexpTokenizer
import os
import regex as re
import pandas as pd
import operator


stop_words = set(stopwords.words("english"))
spath = r"/home/amit/Desktop/ts/txt/"
all_files=os.listdir(spath) # all_files is the list of the files present in -> working dir 
for files in all_files:
    fp = open(str(spath)+str(files))
    text=fp.read()
    text = text.lower()
    data=text

    lines = [wholeline.strip() for wholeline in data.split("\n") if len(wholeline) > 0]
    lines = [nltk.word_tokenize(wholeline) for wholeline in lines]
    lines = [nltk.pos_tag(wholeline) for wholeline in lines]

    for sentence in lines:
        sen = " ".join([words[0].lower() for words in sentence])
        if re.search('experience', sen):
            sen_tokenized = nltk.word_tokenize(sen)
            tagged = nltk.pos_tag(sen_tokenized)
            entities = nltk.chunk.ne_chunk(tagged)
            for subtree in entities.subtrees():
                for leaf in subtree.leaves():
                    if leaf[1] == 'CD':
                        print(leaf[0],files)
            
        

