## using pillow i.e. python image library and pytesseract
from PIL import Image
import pytesseract

for i in range(2,5):
	print("Resume id number: " + str(i))
	img = Image.open(str(i) + ".png")
	text = pytesseract.image_to_string(img, lang = "eng")
	print(text,"\n")
	file = open(str(i) + ".txt","w")#write mode 
	file.write(text) 
	file.close() 